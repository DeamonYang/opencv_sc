#ifndef _NET_SERVER_H
#define _NET_SERVER_H 1

int  server_recv();
int  server_send();


#endif