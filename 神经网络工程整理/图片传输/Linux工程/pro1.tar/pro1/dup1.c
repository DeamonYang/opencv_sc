#include<stdio.h>  
#include<unistd.h>  
#include<stdlib.h>  
#include<sys/types.h>  
#include<sys/socket.h>  
#include<netinet/in.h>  
#include<string.h>  

#define MAX_BUF_SIZE 1024  
#define PORT 8088  
const char SERVER_IP[] =  "172.20.10.4";

void udp_send(int sockfd,char*buf,int len,struct sockaddr *addr,int addrlen)
{
	sendto(sockfd, buf, len , 0, (struct sockaddr *)(&addr), addrlen);
}

int main(void)
{
        int sockfd, addrlen, n;
        char buffer[MAX_BUF_SIZE] = "Hello\r\n";
        struct sockaddr_in addr;
        sockfd = socket(AF_INET, SOCK_DGRAM, 0);
        if (sockfd < 0)
        {
                fprintf(stderr, "socket falied\n");
                exit(EXIT_FAILURE);
        }
        addrlen = sizeof(struct sockaddr_in);
        bzero(&addr, addrlen);
        addr.sin_family = AF_INET;
        addr.sin_port = htons(PORT);
//      addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_addr.s_addr = inet_addr(SERVER_IP);

        while (1)
        {

                sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)(&addr), addrlen);
                sleep(1);

        }
        close(sockfd);
        exit(0);
		

}
